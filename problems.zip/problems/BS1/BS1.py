def binary_search(a,n,x):
    l=0
    r=n-1
    while l<=r:
        m=l+(r-l)//2
        if a[m]==x:
            return True
        elif a[m]>x:
            r=m-1
        else:
            l=m+1
    return False
def xuly(a,query,n):
    ans=[]
    for x in query:
        if binary_search(a,n,x):
            ans.append("YES")
        else:
            ans.append("NO")
    return ans
def doc_ghi():
    import sys
    sys.stdin=open("input5.txt",'r')
    sys.stdout=open("output5.txt",'w')
    data=sys.stdin.read().split()
    n=int(data[0])
    q=int(data[1])
    a=list(map(int,data[2:n+2]))
    query=list(map(int,data[n+2:]))
    ans=xuly(a,query,n)
    sys.stdout.write('\n'.join(ans))
doc_ghi()
    
    