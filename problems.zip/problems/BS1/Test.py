import random

def tao_test_lon():
    N = 100000  # 10^5 số
    Q = 100000 # 10^5 truy vấn
    
    # Tạo mảng A ngẫu nhiên và SẮP XẾP TĂNG DẦN
    A = sorted([random.randint(1, 10**9) for _ in range(N)])
    
    # Tạo Q truy vấn ngẫu nhiên
    queries = [random.randint(1, 10**9) for _ in range(Q)]
    
    # Ghi vào file BS_FIND.INP
    with open("input5.txt", "w") as f:
        f.write(f"{N} {Q}\n")
        f.write(" ".join(map(str, A)) + "\n")
        f.write("\n".join(map(str, queries)) + "\n")

    print("Đã tạo file test lớn BS_FIND.INP thành công!")

tao_test_lon()