# BS1. Kiểm tra sự tồn tại

Trong một mảng đã được sắp xếp, việc tìm kiếm một giá trị $X$ bằng cách duyệt tuần tự sẽ mất rất nhiều thời gian nếu kích thước mảng lớn. Thuật toán tìm kiếm nhị phân giúp tối ưu hóa quá trình này với độ phức tạp $O(\log N)$.

**Yêu cầu:** Cho mảng $A$ gồm $N$ số nguyên đã được sắp xếp tăng dần và $Q$ truy vấn. Với mỗi truy vấn, hãy cho biết số $X$ có xuất hiện trong mảng hay không.

### Dữ liệu vào (Từ file `BS_FIND.INP`):
- Dòng đầu tiên chứa hai số nguyên $N$ và $Q$ ($1 \le N, Q \le 10^5$).
- Dòng thứ hai chứa $N$ số nguyên của mảng $A$ ($|A_i| \le 10^9$).
- $Q$ dòng tiếp theo, mỗi dòng chứa một số nguyên $X$.

### Kết quả (Ghi ra file `BS_FIND.OUT`):
- Với mỗi truy vấn, in ra `YES` nếu tìm thấy, ngược lại in `NO`.

### Ví dụ:

| `BS_FIND.INP` | `BS_FIND.OUT` |
| :--- | :--- |
| 5 3<br>1 3 5 7 9<br>3<br>4<br>9 | YES<br>NO<br>YES |