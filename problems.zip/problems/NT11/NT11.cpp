#include <bits/stdc++.h>
using namespace std;

// Tìm ước nguyên tố lớn nhất (LPF) của các số từ 1 đến n
vector<int> lpf(int n) {
    vector<int> f(n + 1, 0);

    for (int i = 2; i <= n; i++) {
        if (f[i] == 0) {           // i là số nguyên tố
            for (int j = i; j <= n; j += i)
                f[j] = i;          // luôn ghi đè nên cuối cùng là ước nguyên tố lớn nhất
        }
    }
    return f;
}

// Xử lý truy vấn
vector<int> xuly(int q, const vector<int>& a) {
    if (q < 1 || a.empty())
        return {};

    int mx = *max_element(a.begin(), a.end());
    vector<int> f = lpf(mx);

    vector<int> res;
    for (int x : a) {
        if (x <= 1)
            res.push_back(x);
        else
            res.push_back(f[x]);
    }

    return res;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int q;
    cin >> q;

    vector<int> a(q);
    for (int i = 0; i < q; i++)
        cin >> a[i];

    vector<int> kq = xuly(q, a);

    for (int x : kq)
        cout << x << '\n';

    return 0;
}