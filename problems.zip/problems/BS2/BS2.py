def BS_left(a,x):
    l=0
    r=len(a)-1
    ans=-1
    while l<=r:
        m=l+(r-l)//2
        if a[m]==x:
            ans=m
            r=m-1
        elif a[m]>x:
            r=m-1
        else:
            l=m+1
    return ans

def BS_right(a,x):
    l=0
    r=len(a)-1
    ans=-1
    while l<=r:
        m=l+(r-l)//2
        if a[m]==x:
            ans=m
            l=m+1
        elif a[m]>x:
            r=m-1
        else:
            l=m+1
    return ans
def xuly(a,q,n):
    ans=[]
    for x in q:
        res=[]
        l=BS_left(a,x)
        r=BS_right(a,x)
        if l==-1:
            res.append('-1')
            res.append('-1')
            
        else:
            res.append(str(l+1))
            res.append(str(r+1))
        ans.append(' '.join(res))
    return ans

def doc_ghi():
    import sys
    sys.stdin=open("input5.txt",'r')
    sys.stdout=open("output5.txt",'w')
    data=sys.stdin.read().split()
    n=int(data[0])
    q=int(data[1])
    a=list(map(int,data[2:n+2]))
    query=list(map(int,data[n+2:]))
    ans=xuly(a,query,n)
    sys.stdout.write('\n'.join(ans))
doc_ghi()     
    