# BS2. Vị trí đầu tiên và cuối cùng

Khi mảng có nhiều phần tử trùng nhau, tìm kiếm nhị phân cơ bản chỉ trả về một vị trí bất kỳ. Tuy nhiên, trong nhiều bài toán, chúng ta cần xác định chính xác biên của vùng chứa giá trị đó.

- **Yêu cầu:** Cho mảng $A$ có $N$ phần tử đã sắp xếp tăng dần. Với mỗi số $X$, hãy tìm chỉ số (1-indexed) của lần xuất hiện đầu tiên và lần xuất hiện cuối cùng của $X$.
- **Dữ liệu vào (Từ file `BS_BOUND.INP`):**
  - Dòng đầu chứa $N$ và $Q$.
  - Dòng hai chứa mảng $A$.
  - $Q$ dòng sau chứa các số $X$.
- **Kết quả (Ghi ra file `BS_BOUND.OUT`):**
  - Với mỗi $X$, in ra hai số là vị trí đầu và cuối. Nếu không có, in ra `-1 -1`.

### Ví dụ:

| `BS_BOUND.INP` | `BS_BOUND.OUT` |
| :--- | :--- |
| 6 2<br>1 2 2 2 3 5<br>2<br>4 | 2 4<br>-1 -1 |