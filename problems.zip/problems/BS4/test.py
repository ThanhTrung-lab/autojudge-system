import sys
import random
sys.stdout=open('input5.txt','w')
n=1000000
m=200000000
a=[]
sys.stdout.write(f'{n} {m}\n')
for _ in range(n):
    a.append(str(random.randint(1,1000000000)))
sys.stdout.write(' '.join(a))