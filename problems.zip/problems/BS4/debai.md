# Bài 4. Chặt nhị phân trên kết quả - Cưa gỗ

Đây là dạng bài tập quan trọng nhất, dùng tìm kiếm nhị phân để tìm giá trị tối ưu cho một hàm đơn điệu.

**Bài toán:** Mirko cần $M$ mét gỗ. Anh ta có một máy cưa với thiết lập độ cao $H$. Khi cưa, tất cả các phần cây cao hơn $H$ sẽ bị cắt rời. Hãy tìm độ cao $H$ **lớn nhất** để Mirko có được ít nhất $M$ mét gỗ.

- **Yêu cầu:** Cho $N$ cây với chiều cao $H_i$ và số mét gỗ $M$ cần thiết.
- **Dữ liệu vào (Từ file `EKO.INP`):**
  - Dòng 1: $N$ và $M$ ($1 \le N \le 10^6, 1 \le M \le 2 \cdot 10^9$).
  - Dòng 2: $N$ số nguyên chiều cao các cây (mỗi cây $\le 10^9$).
- **Kết quả (Ghi ra file `EKO.OUT`):** Một số nguyên $H$ duy nhất.

### Ví dụ:

| `EKO.INP` | `EKO.OUT` | Giải thích |
| :--- | :--- | :--- |
| 4 7<br>20 15 10 17 | 15 | H là số mét gỗ thu được:<br>$(20 - 15) + (17 - 15) = 7$ (đủ) |