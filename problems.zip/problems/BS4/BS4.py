
def check(a,m,h):
    sum_h=0
    for x in a:
        sum_h+=max(0,(x-h))
    return sum_h>=m

def xuly(a,n,m):
    l=0
    r=max(a)
    ans=0
    while l<=r:
        mid=l+(r-l)//2
        if check(a,m,mid):
            ans=mid
            l=mid+1
        else:
            r=mid-1
    return ans
def doc_ghi():
    import sys
    sys.stdin=open('input5.txt','r')
    sys.stdout=open('output5.txt','w')
    data=sys.stdin.read().split()
    n=int(data[0])
    m=int(data[1])
    a=list(map(int,data[2:]))
    ans=xuly(a,n,m)
    sys.stdout.write(str(ans))
doc_ghi()
            
        
    
    
    
            
    