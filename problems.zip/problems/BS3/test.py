import random

# Tùy chỉnh kích thước mảng (N) và số truy vấn (Q) ở đây
N = 100000
Q = 5501
MIN_VAL, MAX_VAL = 10, 100

# 1. Sinh mảng A gồm N phần tử
A = [random.randint(MIN_VAL, MAX_VAL) for _ in range(N)]

# 2. Sinh Q truy vấn [L, R]
queries = []
for _ in range(Q):
    u = random.randint(MIN_VAL, MAX_VAL)
    v = random.randint(MIN_VAL, MAX_VAL)
    # Đảm bảo L luôn nhỏ hơn hoặc bằng R
    queries.append((min(u, v), max(u, v)))

# 3. Ghi ra file BS_COUNT.INP
with open("input5.txt", "w", encoding="utf-8") as f:
    f.write(f"{N} {Q}\n")
    f.write(" ".join(map(str, A)) + "\n")
    for L, R in queries:
        f.write(f"{L} {R}\n")

print("Đã tạo xong file BS_COUNT.INP!")