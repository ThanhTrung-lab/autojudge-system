# Bài 3. Số lượng phần tử trong đoạn

Đây là ứng dụng trực tiếp của việc tìm kiếm vị trí biên để đếm số lượng phần tử thỏa mãn điều kiện.

- **Yêu cầu:** Cho mảng $A$ có $N$ phần tử (chưa sắp xếp). Cho $Q$ truy vấn, mỗi truy vấn là một cặp $(L, R)$. Hãy đếm xem có bao nhiêu phần tử $A_i$ thỏa mãn $L \le A_i \le R$.
- **Hướng dẫn:** Sắp xếp mảng trước, sau đó dùng chặt nhị phân để tìm vị trí đầu tiên $\ge L$ và vị trí cuối cùng $\le R$.
- **Dữ liệu vào (Từ file `BS_COUNT.INP`):** Tương tự bài trên.
- **Kết quả (Ghi ra file `BS_COUNT.OUT`):** Một số nguyên duy nhất cho mỗi truy vấn.

### Ví dụ:

| `BS_COUNT.INP` | `BS_COUNT.OUT` | Giải thích |
| :--- | :--- | :--- |
| 5 2<br>10 1 5 2 7<br>2 8<br>10 20 | 3<br>1 | Đoạn [2, 8] có: 2, 5, 7<br>Đoạn [10, 20] có: 10 |