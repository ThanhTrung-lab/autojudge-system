def BS_left(a,x):
    l=0
    r=len(a)-1
    ans=-1
    while l<=r:
        m=l+(r-l)//2
        if a[m]>=x:
            ans=m
            r=m-1
        else:
            l=m+1
    return ans

def BS_right(a,x):
    l=0
    r=len(a)-1
    ans=-1
    while l<=r:
        m=l+(r-l)//2
        if a[m]<=x:
            ans=m
            l=m+1
        else:
            
            r=m-1
        
    return ans

def xuly(a,query):
    ans=[]
    for l,r in query:
        x=BS_left(a,l)
        y=BS_right(a,r)
        if x!=-1 and y!=-1 and x<=y:
            ans.append(y-x+1)
        else:
            ans.append(0)
    return ans
def doc_ghi():
    import sys
    sys.stdin=open('input5.txt','r')
    sys.stdout=open('output5.txt','w')
    data=sys.stdin.read().split()
    n=int(data[0])
    q=int(data[1])
    a=list(map(int,data[2:n+2]))
    a.sort()
    query=data[n+2:]
    result=[]
   
    for i in range(0,2*q,2):
        l=int(query[i])
        r=int(query[i+1])
        result.append((l,r))
        
        
    ans=xuly(a,result)
    sys.stdout.write('\n'.join(map(str,ans)))
doc_ghi()
    
    
    
    